<section class="about">
  <div class="container">
    <div class="about__wrapper">
      <div class="about__left">
        <h4 class="title">о компании</h4>
        <p>Magenta Media - у нас вы можете заказать полный спект услуг по живой рекламе. Вывески, банеры, брендированная одежда, сувениры и многое другое</p>
      </div>
      <div class="about__right">
        <img src="{{Vite::asset('resources/assets/about.png')}}" alt="О компании">
      </div>
    </div>
  </div>
</section>