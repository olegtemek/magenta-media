@extends('admin.main')


@section('title')
Главная Dashboard
@endsection

@section('content')

<section class="content">
  <div class="container-fluid">
    <div class="row">
      test
    </div>
  </div>
</section>

@endsection